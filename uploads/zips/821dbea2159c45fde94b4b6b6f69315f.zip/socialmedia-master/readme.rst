###################
Social Media Web Application
###################

This application is done in codeigniter 

*******************
Release Information
*******************

This repo contains in-development code for future releases. To download the
latest stable release please contact me
