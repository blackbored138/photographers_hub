
	function toggle_register_button(){
		var checkedValue =$(".termsCheckbox").is(":checked");	
		//alert(checkedValue);
		}


$(document).on('click','#register_form_btn', function(e){
	registration_submission();
	e.preventDefault();
});

$(document).on('click','#login_form_btn', function(e){
	login_submission();
	e.preventDefault();
});


	function registration_submission(){
		$('#register_form_btn').html('<i class="fa fa-spinner fa-spin" style="font-size:24px"></i>');
		var form = $('#auth-register-form')[0];
		var formData = new FormData(form);
		$.ajax({
				url: 'register_api',
				type: "POST",
				data: formData,
				contentType: false,
				processData: false,
				error: registration_failiure,
                success: registration_success
			});
	}	

	function login_submission(){
		$('#login_form_btn').html('<i class="fa fa-spinner fa-spin" style="font-size:24px"></i>');
		var form = $('#auth-login-form')[0];
		var formData = new FormData(form);
		$.ajax({
				url: 'login_api',
				type: "POST",
				data: formData,
				contentType: false,
				processData: false,
				error: login_failiure,
                success: login_success
			});
	}	
	
	function login_success(data){
		$('#login_form_btn').html('Login');
		var out = jQuery.parseJSON(data);
		var msg = out.data.message;
		var alert = alert_message(msg,'success');
		$('#login_alert').html(alert);
		//console.log(msg.errors);
		window.location.href = 'userhome';
	}
	
	function login_failiure(){
		$('#login_form_btn').html('Login');
	}

	function registration_success(data){
		$('#register_form_btn').html('Register');
		var out = jQuery.parseJSON(data);
		var msg = out.data.message;
		var alert = alert_message(msg,'danger');
		$('#register_alert').html(alert);	

	}
	
	function registration_failiure(){
		$('#register_form_btn').html('Register');
		alert(13246);
	}



	function alert_message(message,status){
		var alert = '<div class="alert alert-'+ status +' alert-dismissible fade show" role="alert">'+message+'<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button></div>';
		return alert;
	}
