<?php


/******* Authentication Check *******/

if (! function_exists('auth_check')) {
    function auth_check(){
        $CI = & get_instance(); 
        $session = $CI->session->userdata('login_status');
        $user_id = magicfunction($CI->session->userdata('login_status'),'d');
		$user_status = check_user_id($user_id);
		if ($session == '' || $user_status) {
            redirect('authentication');
        }
    }   
}

/******* Authentication Check *******/



	//============ Check User Email ============
    if (! function_exists('check_user_id')) {
        function check_user_id($uid)
        {
            $CI = & get_instance(); 
            $result = $CI->db->get_where('ci_users', array('user_id' => $uid));

            if($result->num_rows() > 0){
                $result = $result->row_array();
                return true;
            }
            else {
                return false;
            }
        }
    }


?>