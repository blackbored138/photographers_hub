<?php
function response($status,$data)
{
	header("HTTP/1.1 ".$status);
	
	$response['status']=$status;
	$response['data']=$data;
	
	$json_response = json_encode($response);
	echo $json_response;
	exit();
}

function check_post()
{
	$CI = & get_instance();  
	if($CI->input->post())
		return;
	else
		exit();	
}

	
if (! function_exists('alert_message')) {
    function alert_message(){
        $CI = & get_instance();  
        $status = $CI->session->userdata('alert');
        $message = $CI->session->userdata('alert_msg');
        return '<div class="alert alert-'.$status.' alert-dismissible fade show" role="alert">
        '.$message.'
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
        <span aria-hidden="true">&times;</span>
        </button>
        </div>';
    }   
}


?>