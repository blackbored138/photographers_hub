<?php


if (!function_exists('magicfunction')){
	function magicfunction($string, $action) {
	$secret_key = '@@s-m-c-i-m-20210217@#';
	$secret_iv = 'smcim_encrypt_and_decrypt_20210217';
	$output = false;
	$encrypt_method = "AES-256-CBC";
	$key = hash('sha256', $secret_key );
	$iv = substr(hash( 'sha256', $secret_iv ), 0, 16 );
	if( $action == 'e' ) {
		$output = base64_encode( openssl_encrypt( $string, $encrypt_method, $key, 0, $iv ) );
	}
	else if( $action == 'd' ){
		$output = openssl_decrypt( base64_decode( $string ), $encrypt_method, $key, 0, $iv );
	}
	return $output;
	}
}


function encrypt_data($result,$indexes){
	$i = 0;
	while($i < count($result)):
		foreach($indexes as $index):
			$result[$i]->$index = magicfunction($result[$i]->$index,'e');
		endforeach;		
			$i++;
	endwhile; 


	return $result;
}


?>