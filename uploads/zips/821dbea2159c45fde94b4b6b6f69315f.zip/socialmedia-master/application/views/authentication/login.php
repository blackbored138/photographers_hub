
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Social Media Project</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="description" content="" />
<meta name="keywords" content="" />

<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous">  <!-- Google Font: Source Sans Pro -->

<link rel="stylesheet" type="text/css" href="<?= base_url() ?>assets/users/css/animate.css">
<link rel="stylesheet" type="text/css" href="<?= base_url() ?>assets/users/css/bootstrap.min.css">
<link rel="stylesheet" type="text/css" href="<?= base_url() ?>assets/users/css/line-awesome.css">
<link rel="stylesheet" type="text/css" href="<?= base_url() ?>assets/users/css/line-awesome-font-awesome.min.css">
<link rel="stylesheet" type="text/css" href="<?= base_url() ?>assets/users/css/font-awesome.min.css">
<link rel="stylesheet" type="text/css" href="<?= base_url() ?>assets/users/lib/slick/slick.css">
<link rel="stylesheet" type="text/css" href="<?= base_url() ?>assets/users/lib/slick/slick-theme.css">
<link rel="stylesheet" type="text/css" href="<?= base_url() ?>assets/users/css/style.css">
<link rel="stylesheet" type="text/css" href="<?= base_url() ?>assets/users/css/responsive.css">
</head>


<body class="sign-in">
	

	<div class="wrapper">
		

		<div class="sign-in-page">
			<div class="signin-popup">
				<div class="signin-pop">
					<div class="row">
						<div class="col-lg-6">
							<div class="cmp-info">
								<div class="cm-logo">
									<img src="<?= base_url() ?>assets/users/images/cm-logo.png" alt="">
									<p>Social Media Project is a social media platform free to use</p>
								</div><!--cm-logo end-->	
								<img src="<?= base_url() ?>assets/users/images/cm-main-img.png" alt="">			
							</div><!--cmp-info end-->
						</div>
						<div class="col-lg-6">
							<div class="login-sec">
								<ul class="sign-control">
									<li data-tab="tab-1" class="current"><a href="#" title="">Sign in</a></li>				
									<li data-tab="tab-2"><a href="#" title="">Sign up</a></li>				
								</ul>			
								<div class="sign_in_sec current" id="tab-1">
									<div id="login_alert"></div>

									<h3>Sign in</h3>
									<?php echo form_open('authentication','id="auth-login-form"'); ?>
										<div class="row">
											<div class="col-lg-12 no-pdd">
												<div class="sn-field">
													<input type="text" name="username" placeholder="Username">
													<i class="la la-user"></i>
												</div><!--sn-field end-->
											</div>
											<div class="col-lg-12 no-pdd">
												<div class="sn-field">
													<input type="password" name="password" placeholder="Password">
													<i class="la la-lock"></i>
												</div>
											</div>
											<div class="col-lg-12 no-pdd">
												<div class="checky-sec">
													<div class="fgt-sec">
														
													</div><!--fgt-sec end-->
													<a href="#" title="">Forgot Password?</a>
												</div>
											</div>
											<div class="col-lg-12 no-pdd">
												<button  id="login_form_btn">Login</button>
											</div>
										</div>
									<?php echo form_close();?>       
									
								</div><!--sign_in_sec end-->
								
                                <div class="sign_in_sec" id="tab-2">
									<div id="register_alert"></div>
									<div class="dff-tab current" id="tab-3">
									<h3>Sign up</h3>

									<?php echo form_open('authentication','id="auth-register-form"'); ?>
											<div class="row">
												<div class="col-lg-12 no-pdd">
													<div class="sn-field">
														<input type="text" name="user_full_name" placeholder="Full Name">
														<i class="la la-user"></i>
													</div>
												</div>
												<div class="col-lg-12 no-pdd">
													<div class="sn-field">
														<input type="text" name="user_place" placeholder="Place">
														<i class="la la-globe"></i>
													</div>
												</div>
                                                <div class="col-lg-12 no-pdd">
													<div class="sn-field">
														<input type="text" name="user_phone" placeholder="Phone">
														<i class="la la-phone"></i>
													</div>
												</div>    
                                                <div class="col-lg-12 no-pdd">
													<div class="sn-field">
														<input type="text" name="user_mail" placeholder="Email">
														<i class="la la-envelope"></i>
													</div>
												</div>
												<div class="col-lg-12 no-pdd">
													<div class="sn-field">
														<select name="user_gender">
															<option value="1">Male</option>
															<option value="2">Female</option>
														</select>
														<i class="la la-dropbox"></i>
														<span><i class="fa fa-ellipsis-h"></i></span>
													</div>
												</div>
												<div class="col-lg-12 no-pdd">
													<div class="sn-field">
														<input type="text" name="user_name" placeholder="Username">
														<i class="la la-user"></i>
													</div>
												</div>
												<div class="col-lg-12 no-pdd">
													<div class="sn-field">
														<input type="password" name="user_password" placeholder="Password">
														<i class="la la-lock"></i>
													</div>
												</div>
												<div class="col-lg-12 no-pdd">
													<div class="sn-field">
														<input type="password" name="repeat_password" placeholder="Repeat Password">
														<i class="la la-lock"></i>
													</div>
												</div>
												<div class="col-lg-12 no-pdd">
													<div class="checky-sec st2">
														<div class="fgt-sec">
															<input type="checkbox" id="c2" onchange="toggle_register_button()">
															<label for="c2">
																<span></span>
															</label>
															<small>Yes, I understand and agree to the social media Terms & Conditions.</small>
														</div><!--fgt-sec end-->
													</div>
												</div>
												<div class="col-lg-12 no-pdd">
													<button id="register_form_btn">Register</button>
												</div>
											</div>
											<?php echo form_close();?>       
									</div><!--dff-tab end-->
									<div class="dff-tab" id="tab-4">
										<form>
											<div class="row">
												<div class="col-lg-12 no-pdd">
													<div class="sn-field">
														<input type="text" name="company-name" placeholder="Company Name">
														<i class="la la-building"></i>
													</div>
												</div>
												<div class="col-lg-12 no-pdd">
													<div class="sn-field">
														<input type="text" name="country" placeholder="Country">
														<i class="la la-globe"></i>
													</div>
												</div>
												<div class="col-lg-12 no-pdd">
													<div class="sn-field">
														<input type="password" name="password" placeholder="Password">
														<i class="la la-lock"></i>
													</div>
												</div>
												<div class="col-lg-12 no-pdd">
													<div class="sn-field">
														<input type="password" name="repeat-password" placeholder="Repeat Password">
														<i class="la la-lock"></i>
													</div>
												</div>
												<div class="col-lg-12 no-pdd">
													<div class="checky-sec st2">
														<div class="fgt-sec">
															<input type="checkbox" name="cc" id="c3">
															<label for="c3">
																<span></span>
															</label>
															<small>Yes, I understand and agree to the workwise Terms & Conditions.</small>
														</div><!--fgt-sec end-->
													</div>
												</div>
												<div class="col-lg-12 no-pdd">
													<button type="submit" value="submit">Get Started</button>
												</div>
											</div>
										</form>
									</div><!--dff-tab end-->
								</div>		
							</div><!--login-sec end-->
						</div>
					</div>		
				</div><!--signin-pop end-->
			</div><!--signin-popup end-->
			<div class="footy-sec">
				<div class="container">
					<ul>
						<li><a href="#" title="">Help Center</a></li>
						<li><a href="#" title="">Privacy Policy</a></li>
						<li><a href="#" title="">Community Guidelines</a></li>
						<li><a href="#" title="">Cookies Policy</a></li>
						<li><a href="#" title="">Career</a></li>
						<li><a href="#" title="">Forum</a></li>
						<li><a href="#" title="">Language</a></li>
						<li><a href="#" title="">Copyright Policy</a></li>
					</ul>
					<p><img src="<?= base_url() ?>assets/users/images/copy-icon.png" alt="">Copyright 2018</p>
				</div>
			</div><!--footy-sec end-->
		</div><!--sign-in-page end-->


	</div><!--theme-layout end-->



<script type="text/javascript" src="<?= base_url() ?>assets/users/js/jquery.min.js"></script>
<script type="text/javascript" src="<?= base_url() ?>assets/users/js/popper.js"></script>
<script type="text/javascript" src="<?= base_url() ?>assets/users/js/bootstrap.min.js"></script>
<script type="text/javascript" src="<?= base_url() ?>assets/users/lib/slick/slick.min.js"></script>
<script type="text/javascript" src="<?= base_url() ?>assets/users/js/script.js"></script>
<script type="text/javascript" src="<?= base_url() ?>assets/ajax/auth.js"></script>
</body>
</html>
