<link rel="stylesheet" href="<?= base_url() ?>assets/croppie/croppie.css" />
<script src="<?= base_url() ?>assets/croppie/croppie.min.js"></script>

<section class="companies-info" style="margin-top: 25vh;">
            <div class="main-section">
				<div class="container">
					<div class="main-section-data">

<div class="user_profile">
										<div class="user-pro-img">
                                            
                                            <div id="upload-demo"></div>
                                            <img src="<?=base_url() ?>p_image/<?= $profile_image ?>/200/200" alt="Profile Image" id="profile_image">
                                            <br><h3 style="color: #071944;"><b id="upload_status_msg">Upload your profile image</b></h3>
										</div><!--user-pro-img end-->
										<div class="user_pro_status">
											<ul class="flw-hr">
												<li>
                                                <?php echo form_open('class="form" id="profile-page" name="profile-page-form" '); ?>

                                                    <input type="file" name="upload" class="form-control" id="upload" accept="image/*">
                                                
                                                <?php echo form_close(); ?>       

                                                    </a>
                                                </li>
											</ul>
                                            
											<ul class="flw-status">
												<li>
													<a class="btn-custom" id="upload-image">Upload <i class="fa fa-upload"></i></a>
												</li>
												<li>
													<a class="btn-custom-danger" id="remove-image">Remove <i class="fa fa-times"></i></a>
												</li>
											</ul>
										</div><!--user_pro_status end-->
										
									</div><!--user_profile end-->
</div>
</div>
</div>
</section>



<script>  
//1920 * 902
        $('#upload').on('change', function () {

            $('#profile_image').hide();
            $('#upload-demo').croppie('destroy');
            $uploadCrop = $('#upload-demo').croppie({ 
                    enableExif: true,
                    boundary: {
                    width: 210,
                    height: 210
            },
            viewport: {
                width:200,
                height: 200,
                type: 'circle'
            }
		});

        var reader = new FileReader();
            reader.onload = function (e) {
            $uploadCrop.croppie('bind', {
                url: e.target.result
            }).then(function(){
                    $('.upload-result').show();
                    console.log('jQuery bind complete');
                    $('#upload-image-form').val(e.target.result);
                    $('#upload_status_msg').html('Click on Upload to save');
                    $('#upload_status_msg').css('color','#28a745');

            });

        }
        reader.readAsDataURL(this.files[0]);

      });
    


        $('#remove-image').click(function(event) {
            $('#upload-demo').croppie('destroy');
            $('#profile_image').show();
            $('#profile-page')[0].reset();
            $('#upload_status_msg').html('Profile Photo removed');
            $('#upload_status_msg').css('color','#dc3545');


        });

        $('#upload-image').click(function(event) {
            $('#upload-image').hide();

            if(typeof $uploadCrop == 'undefined'){
                $('#upload-image').show();
                $('#upload_status_msg').html('Please select an image');
                $('#upload_status_msg').css('color','#dc3545');

                return;
            }
            $uploadCrop.croppie('result', {
                type: 'canvas',
                size: 'viewport'

            }).then(function(response) {
                var formData = new FormData($("#profile-page")[0]);
                formData.append('photo', response);

                $.ajax({
                    url: 'profile_image_store',
                    type: 'POST',
                    data: formData,
                    processData: false,
                    contentType: false,
                    success: function(data) {
                        //console.log("Uploaded Successfully");
                        $('#upload_status_msg').css('color','#28a745');
                        $('#upload_status_msg').html('Uploaded Successfully');
                        $('#profile-page')[0].reset();
                        $('#upload-demo').croppie('destroy');
                        $('#upload-image').show();
                        $('#profile_image').show();
                        $('#profile_image').attr('src',response);

                       //$('#profile_image').show();

                    }
                });
            });
        });
 
    </script>
