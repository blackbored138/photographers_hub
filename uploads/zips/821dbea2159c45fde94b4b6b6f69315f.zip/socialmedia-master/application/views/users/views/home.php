    <main>
        <div class="main-section">
            <div class="container">
                <div class="main-section-data">
                    <div class="row">

                        <div class="col-lg-3 col-md-4 pd-left-none no-pd">
                            <div>
                                <div class="main-left-sidebar no-margin">

                                <?php if(!$this->session->userdata('login_status')): ?> 

                                    <div class="user-data full-width">
                                        <div class="py-4 px-4">
                                            <a href="<?= base_url() ?>login"><button class="btn btn-outline-danger text-uppercase w-100 font-weight-bold">Login</button></a>
                                        </div>
                                        <h3>Don't have a account</h3>
                                        <div class="py-4 px-4">
                                            <a href="<?= base_url() ?>login"><button class="btn btn-outline-danger text-uppercase w-100 font-weight-bold">Sign Up</button></a>
                                        </div>
                                    </div>

                                <?php endif; ?>

                                </div>
                            </div>
                        </div>

                        <div class="col-lg-6 col-md-8 no-pd">
                        <div>



                            <!----->

                            <div class="posty mb-4" id="add_new_post2">
                                <div class="post-bar no-margin" id="mainfeed23">
                                    <div class="post_topbar">
                                            <div class="post_new_contents">
                                                        <img src="<?=base_url() ?>p_image/<?= $profile_image ?>/30/30" alt="user profile">
                                                        <div class="usy-name-add">
                                                            <h3 class=""><a id="add_new_post_box">Add a new post</a></h3>
                                                        </div>
                                            </div>   
                                            <?php echo form_open('','name="upload-file" class="col-12" enctype="multipart/form-data" id="form-upload-file"'); ?>

                                            <div class="epi-sec" id="add_new_post" style="display: block;">
                                                <textarea class="post_new_contents" name="post_content_text" id="the-textarea" maxlength="300" placeholder="Start Typin..."autofocus></textarea>
                                                <div id="the-count">
                                                    <span id="current">0</span>
                                                    <span id="maximum">/ 300</span>
                                                </div>    
                                                <br>
                                            <div id="message_box" class="col-12"></div> 
                                            <?php echo form_close();?>       
   
                                            <div class="row post_new_contents">                                             
                                                <label class="col-12 file post_new_contents">
                                                    <button class="post_new_contents imgbuts" id="file" aria-label="File browser example">Browse...</button>

                                                </label>     

                                            <!------>
                                            
                                            <!------>
                                            <div class="progress">
				                                <div class="progress-bar" role="progressbar"  style="width:0%">
                                                    <span class="sr-only">0</span>
                                                </div>
                                            </div>
                                            <h2 class="success_msg col-12"></h2>
                                            
                                            </div>
                                            </div>
                                            <button id="post_send" class="button post_new_contents" onclick="save_muliple_image()"><span>Post </span></button>
      
                                    </div>                      
                                </div>                           
                            </div>


                            <!----->
                        <div class="posts-section">
                            
                            <?php $i = 0; foreach($home_post as $home_posts):  ?>
                            <div class="posty mb-4">
                                <div class="post-bar no-margin" id="mainfeed23">
                                    <div class="post_topbar">
                                            <div class="usy-dt">
                                                        <img src="<?=base_url() ?>p_image/<?= $home_posts->user_photo ?>/30/30" alt="User Photo">
                                                        <div class="usy-name">
                                                            <h3><?= $home_posts->user_name ?></h3>
                                                            <p><?= $home_posts->user_full_name ?></p>
                                                            <span><i class="fa fa-clock-o" aria-hidden="true"></i>
                                                                <?= get_time_ago($home_posts->posted_on) ?>
                                                            </span>
                                                        </div>
                                            </div>
                                            <div class="ed-opts">
                                                <a href="#" title="" class="ed-opts-open"><i class="fa fa-ellipsis-v"></i></a>
                                                <ul class="ed-options">
                                                    <li><a href="#" title="">Edit Post</a></li>
                                                    <li><a href="#" title="">Copy link</a></li>
                                                    <li><a href="#" title="">Hide</a></li>
                                                </ul>                                            
                                            </div>
                                    </div>
                                    <div class="epi-sec">
                                        <ul class="bk-links">
                                            <li><a class="btn btn-sm btn-danger" href="#" title=""><i class="fa fa-bookmark"></i></a></li>
                                            <li><a class="btn btn-sm btn-danger" href="#" title=""><i class="fa fa-envelope"></i></a></li>
                                            <li><a class="btn btn-sm btn-danger" href="#" title=""><i class="fa fa-link"></i></a></li>
                                        </ul>
                                    </div>
                                    <div class="job_descp accountnone row">
                                        <div class="col-12">

                                        <div id="home_slider<?=$i?>" class="carousel slide" data-ride="carousel">

                                            <!-- Indicators -->
                                            <!--<ul class="carousel-indicators">
                                                <li data-target="#demo" data-slide-to="0" class="active"></li>
                                                <li data-target="#demo" data-slide-to="1"></li>
                                                <li data-target="#demo" data-slide-to="2"></li>
                                            </ul>-->

                                            <!-- The slideshow -->
                                            <div class="carousel-inner">

                                                <?php $j=0; foreach($home_posts->file as $post_images): 
                                                    //print_r($post_images); exit();
                                                    ?>
                                                    <div class="carousel-item <?= ($j == 0) ?'active' : ''; ?>  ">
                                                        <img class="w-100" src="<?=base_url() ?>u_posts/<?= $post_images ?>/460/280">
                                                    </div>
                                                <?php $j++; endforeach; ?>
                                                
                                            </div>

                                            <!-- Left and right controls -->
                                            <?php if($j > 1): ?>
                                                <a class="carousel-control-prev" href="#home_slider<?=$i?>" data-slide="prev">
                                                    <span class="carousel-control-prev-icon"></span>
                                                </a>
                                                <a class="carousel-control-next" href="#home_slider<?=$i?>" data-slide="next">
                                                    <span class="carousel-control-next-icon"></span>
                                                </a>
                                            <?php endif; ?>
                                        </div>

                                        </div> 
                                        <div class="col-12">
                                            <p class="posts_description"><?= substr($home_posts->post_text,0,100) ?><a href="#" title="View More">view more</a></p>
                                        </div>                                                                            
                                        <ul class="skill-tags">
                                            <li><a href="#" title="">Tag 1</a></li>
                                            <li><a href="#" title="">Tag 2</a></li>
                                            <li><a href="#" title="">Tag 3</a></li>
                                        </ul>
                                    </div>

                                    <div class="job-status-bar btm-line">
                                        <ul class="like-com">
                                            <li>
                                                <a href="#" class="active"><i class="fa fa-heart"></i> Like</a>
                                                <span>25</span>
                                            </li>
                                            <li>
                                                <a href="#" class="com"><i class="fa fa-comment"></i> Comments 15</a>
                                            </li>
                                        </ul>
                                        <a href="#"><i class="fa fa-eye"></i>Views 50</a>
                                    </div>
                                </div>
                            
                                <div class="comments_area23" style="display: none">
                                    <div>
                                        <div class="comment-section">
                                            <div class="comment-sec">
                                                <ul>
                                                    <li>
                                                        <div class="comment-list">
                                                            <div class="bg-img">
                                                                <img src="./storage" alt="Robel" onerror="this.onerror=null;this.src='./images/resources/user-pic.png';">
                                                            </div>
                                                            <div class="comment">
                                                                <a href="./user/robel">
                                                                    <h3>Robel</h3>
                                                                </a>
                                                                <span><img src="images/clock.png" alt="">
                                                                3 Month
                                                                ago</span>
                                                                <p>i can do</p>
                                                            </div>
                                                        </div>
                                                    </li>
                                                    <li>
                                                        <div class="comment-list">
                                                            <div class="bg-img">
                                                                <img src="./storage" alt="Workwise Admin" onerror="this.onerror=null;this.src='./images/resources/user-pic.png';">
                                                            </div>
                                                            <div class="comment">
                                                                <a href="./user/workwise">
                                                                <h3>Workwise Admin</h3>
                                                                </a>
                                                                <span><img src="images/clock.png" alt="">
                                                                16 Days
                                                                ago</span>
                                                                <p>kjhkl;</p>
                                                            </div>
                                                        </div>
                                                    </li>

                                                    <a class="viewBtn" href="./project/test-Q78Dm1"><h3>View More</h3></a>
                                                </ul>
                                            </div>
                                            <p>Please <a href="./login?redirect_to=eyJpdiI6ImtaaVJaSE5KMmVTMlVUYjNpOGtxelE9PSIsInZhbHVlIjoiSG83TlhPQStyZjN2OXMra2dCaFUyZz09IiwibWFjIjoiN2UwNTY0YTBhNDJkNGEwZDMwY2IyZmMyOWYwY2Y0NDg3NTVmM2U4YTM5NTk5YTVmNjAzNzQ3YmU0MDYxNzhkYiJ9">login</a> to add your comment on feed..</p>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <?php $i++; endforeach; ?>


                        <div id="latest_profiles">
                        <div class="top-profiles">
                            <div class="pf-hd">
                                <h3>Latest Profiles</h3>
                                <i class="la la-ellipsis-v"></i>
                            </div>

                            <div class="profiles-slider">       

                                <?php foreach($latest_profile as $latest_profiles): ?>
                                    <div class="user-profy">
                                            <img src="<?=base_url() ?>p_image/<?= $latest_profiles->user_photo ?>/50/50" alt="user_profile" class="img">
                                            <h3><?=$latest_profiles->user_full_name ?></h3>
                                            <span><?=$latest_profiles->user_name ?></span>
                                                <ul>
                                                    <li><a href="./login?redirect_to=eyJpdiI6IjdBRlBzVWQ0WjBYd2pIekpOYVlTVXc9PSIsInZhbHVlIjoiaW5jNHhzZ2dsUm9CYWVraURIdzIyUT09IiwibWFjIjoiNjMyZDk0ZTk1MTIxZjUzODdlZTliZDA5ZmQzMmFlNzY1ZGE0MzNiMDkyYmU1NWE3NzkxNDkwMmRiZjVkYzcwYSJ9" title="Follow me" class="follow">Follow</a></li>
                                                    <li><a href="./login?redirect_to=eyJpdiI6IjdnOENJVUV2ZDdFc0ZCM2R5SlpKTnc9PSIsInZhbHVlIjoiVVdYbDVndG1KVFd6c0ZNdHhFTGRYUT09IiwibWFjIjoiMTVmNWE3M2U0NmYxMmZkZTAxMjM3MmU3MTE4MTk5OWMyNDY0NGE5YjViNTRiNzcxMDU2YzE3MDhkNmU1MDFjOSJ9" title="" class="message-us"><i class="fa fa-envelope"></i></a></li>
                                                </ul>
                                                <a href="<?= base_url() ?>profile/<?= $latest_profiles->user_name ?>" title="View Profile" class="view-more-pro">View Profile</a>
                                    </div>

                                <?php endforeach; ?>

                            </div>
                        </div>
                        
                    </div>




                </div>
            </div>

        </div>

        <div class="col-lg-3 pd-right-none no-pd">
            <div>
                <div class="right-sidebar">
                    <div class="widget widget-jobs">
                        <div class="sd-title">
                            <h3>Recently Viewed Profiles</h3>
                            <i class="la la-ellipsis-v"></i>
                        </div>
                        <div class="jobs-list">

                            <div class="job-info">
                                <div class="job-details">
                                    <a href="./job/sfsdfa-eVWIaM"><h3>sfsdfa</h3></a>
                                    <p>sdfsdf</p>
                                </div>
                                <div class="hr-rate">
                                    <span>$200</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="widget suggestions full-width">
                    <div class="sd-title">
                        <h3>Suggested Profiles</h3>
                        <i class="la la-ellipsis-v"></i>
                    </div>
                    <div class="suggestions-list">
                        <div>

                        <?php foreach($suggested_profile as $suggested_profiles): ?>

                            <div class="suggestion-usd">
                                <img src="<?=base_url() ?>p_image/<?= $suggested_profiles->user_photo ?>/50/50" alt="user_profile">
                                <div class="sgt-text">
                                    <a href="<?= base_url() ?>profile/<?= $suggested_profiles->user_name ?>">
                                        <h4><?=$suggested_profiles->user_full_name ?></h4>
                                    </a>
                                    <span><?=$suggested_profiles->user_name ?></span>
                                </div>
                                <span>
                                    <a href="<?= base_url() ?>profile/<?= $suggested_profiles->user_name ?>">
                                        <i class="fa fa-plus"></i>
                                    </a>
                                </span>
                            </div>

                        <?php endforeach; ?>

                            <div class="view-more">
                                <a href="<?= base_url() ?>all_profiles" title="">View More</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </main>


<script>
    $('textarea').keyup(function() {
    
    var characterCount = $(this).val().length,
        current = $('#current'),
        maximum = $('#maximum'),
        theCount = $('#the-count');
      
    current.text(characterCount);
   
    
    /*This isn't entirely necessary, just playin around*/
    if (characterCount < 70) {
      current.css('color', '#47cf73');
    }
    if (characterCount > 70 && characterCount < 90) {
      current.css('color', '#6d5555');
    }
    if (characterCount > 90 && characterCount < 100) {
      current.css('color', '#793535');
    }
    if (characterCount > 100 && characterCount < 120) {
      current.css('color', '#841c1c');
    }
    if (characterCount > 120 && characterCount < 139) {
      current.css('color', '#8f0001');
    }
    
    if (characterCount >= 140) {
      maximum.css('color', '#8f0001');
      current.css('color', '#8f0001');
      theCount.css('font-weight','bold');
    } else {
      maximum.css('color','#666');
      theCount.css('font-weight','normal');
    }
    
        
  });


$(document).on('click','#add_new_post_box', function(e){
    $('#add_new_post').toggle();
    e.preventDefault;
});

</script>


<script>
var xp = 0;
var input_btn = 0;
var dts = [];
$(document).on("click", ".imgbuts", function (e) {
  input_btn++;
  $("#form-upload-file").append(
    "<input type='file' style='display: none;' name='upload_files[]' id='filenumber" +
      input_btn +
      "' class='img_file upload_files' accept='.gif,.jpg,.jpeg,.png,' multiple/>"
  );
  $("#filenumber" + input_btn).click();
  e.preventDefault();
});

$(document).on("change", ".upload_files", function (e){
  files = e.target.files;
  filesLength = files.length;
  for (var i = 0; i < filesLength; i++) {
	  xp++; 
    var f = files[i];
    var res_ext = files[i].name.split(".");
    var img_or_video = res_ext[res_ext.length - 1];
    var fileReader = new FileReader();
    fileReader.name = f.name;
      fileReader.onload = function (e) {
        var file = e.target;
        $("#message_box").append(
          "<article class='suggested-posts-article remove_artical" +
            xp +
            "' data-file='" +
            file.name +
            "'><div class='posts_article background_v" +
            xp +
            "' style='background-image: url(" +
            e.target.result +
            ")'></div><div class='p_run_div'><span class='pp_run progress_run" +
            xp +
            "' style='opacity: 1;'></span></div><p class='fa_p p_for_fa" +
            xp +
            "'><span class='cancel_mutile_image btnxc cancel_fa" +
            xp +
            "' deltsid='"+0+"'>&#10006;</span><span class='btnxc btnxc_r' >&#10004;</span></p></article>"
        );
      };
      fileReader.readAsDataURL(f);
  }
  
});


function save_muliple_image() { 
    suggested = $(".suggested-posts-article").length;
  if (suggested > 0) {
    $(".cancel_mutile_image").prop("disabled", true);
    $("#post_send").prop("disabled", true);
    var formData = new FormData(document.getElementById("form-upload-file"));
	formData.append("dts", dts); 
    var xhr = new window.XMLHttpRequest();
    $.ajax({
      url: 'save_post',
      type: "POST",
      data: formData,
      processData: false,
      contentType: false,
      success: function (data) { 
        $(".main-content").find(".message-loading-overlay2").remove();
        toastr.options.iconClass = "toast-success";
        toastr.info('Posts added successfully', 'Post Status');
        $('.success_msg').hide();
       
        $('.success_msg').html();
        $('.progress-bar').html();
        $('.progress-bar').hide();
        $('.progress-bar').css('background','#fff');
      },
      error: function (e) {
        $("#preview_file_div ul").html(
          "<li class='text-danger'>Something wrong! Please try again.</li>"
        );
        toastr.info('Posts wasnt added successfully', 'Post Status');

      },
      xhr: function (e) {
        xhr.upload.addEventListener(
          "progress",
          function (e) {
            console.log(e);
            if (e.lengthComputable) {
              var percentComplete = ((e.loaded || e.position) * 100) / e.total;
              if(percentComplete==100){
              $(".progress-bar").width(percentComplete + "%").html('99' + "%");
              }else{ $(".progress-bar").width(percentComplete + "%").html(percentComplete + "%"); }
            }
          },
          false
        );
        xhr.addEventListener("load", function (e) {
          $('.progress-bar').css("background","#071944").html('100' + "%");
		  $(".btnxc_r").show();
		  $(".success_msg").html('File Uploaded');
		  $(".success_msg").show();
          $('#message_box').html('');
		  $(".cancel_mutile_image").remove();
        });
        return xhr;
      },
    });
  } else {
    $(".messaf").show();
  }
}


var rty=0;
$(document).on("click", ".cancel_mutile_image", function (e) {
  $('.cancel_mutile_image').each(function(){ 
	  chk_id = $(this).attr('deltsid');
	  if(chk_id==0){ rty++; $(this).attr('deltsid',rty); }
  });
  deltsid = $(this).attr('deltsid');
  dts.push(deltsid);
  $(this).parents(".suggested-posts-article").remove();
});

</script>


