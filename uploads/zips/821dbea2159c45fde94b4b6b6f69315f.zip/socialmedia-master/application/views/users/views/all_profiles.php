    <section class="companies-info">
        <div class="container">
            <div class="company-title">
                
                <h3>
                    <div class="row">
                        <div class="col-md-6 col-sm-12">All Users</div>
                        <div class="col-md-6 col-sm-12">
                            <i title="Random" class="fa fa-random float-right profile-sort-i" sort-order="RANDOM"></i>
                            <i title="Ascending" class="fa fa-sort-amount-asc float-right profile-sort-i" sort-order="asc"></i>
                            <i title="Descending" class="fa fa-sort-amount-desc float-right profile-sort-i" sort-order="desc"></i>
                        </div>

                    </div>
                </h3>
            </div>

            <div class="companies-list">
                <input type="hidden" id="sort_order_tbox" value="desc">
                <div class="row" id="profiles_list">
                    
                 





                </div>
            </div>
            
            <div class="process-comm" id="loader-dots" style="display: none;">
                <div class="spinner">
                    <div class="bounce1"></div>
                    <div class="bounce2"></div>
                    <div class="bounce3"></div>
                </div>
            </div>
            
        </div>
    </section>


<script>    

    $(window).on('load', function(){
        loadprofiles(true);
    });

    $(document).on('click','.profile-sort-i', function(e){
        var sort_order = $(this).attr('sort-order');
        $('#sort_order_tbox').val(sort_order);
        loadprofiles(false);

        e.preventDefault();
    });

	function loadprofiles(initial = true){
        $('#loader-dots').toggle();
        var sort_order = $('#sort_order_tbox').val();  
        var numItems = (initial) ? $('.profile_card').length : '0';
        var csrfName = '<?php echo $this->security->get_csrf_token_name(); ?>',
                 csrfHash = '<?php echo $this->security->get_csrf_hash(); ?>';

        var dataJson = { [csrfName]: csrfHash, offset: numItems,order: sort_order };
		$.ajax({
				url: 'profileslist',
				type: "POST",
				data: dataJson,
				error: profile_load_failiure,
                success: function(data) {
                    profile_load_success(data,initial);
                }
			});
	}	

 
    function profile_load_failiure(){
        $('#loader-dots').toggle();

    }

    function profile_load_success(data,initial){
        $('#loader-dots').toggle();
        if(initial)
            $('#profiles_list').append(data);
        else
            $('#profiles_list').html(data);
        //alert(321);
    }

 $(window).scroll(function(){
 
  var position = $(window).scrollTop();
  var bottom = $(document).height() - $(window).height();

  if( bottom == position){
    loadprofiles(true);
  }
});
</script>    