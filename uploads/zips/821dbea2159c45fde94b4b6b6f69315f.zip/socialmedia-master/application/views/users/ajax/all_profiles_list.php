<?php foreach($profile as $profiles): ?>
<div class="col-lg-3 col-md-4 col-sm-6 col-12 profile_card">
                        <div class="company_profile_info">
                            <div class="company-up-info">
                                <img src="<?=base_url() ?>p_image/<?= $profiles->user_photo ?>/50/50" alt="user_image">
                                    <h3><?=$profiles->user_full_name ?></h3>
                                    <h4><?=$profiles->user_name ?></h4>
                                    <h4><?=$profiles->user_place ?></h4>
                                        <ul>
                                            <li><a href="#" title="" class="follow">Follow</a></li>
                                            <li><a href="<?= base_url() ?>profile/<?= $profiles->user_name ?>" title="" class="message-us btn-sm"><i class="fa fa-eye"></i></a></li>
                                            <li><a href="#" title="" class="btn-danger btn-sm"><i class="fa fa-envelope"></i></a></li>
                                        </ul>
                            </div>
                            <a href="<?= base_url() ?>profile/<?= $profiles->user_name ?>" title="View Profile" class="view-more-pro">View Profile</a>
                        </div>
</div>
<?php endforeach; ?> 

               