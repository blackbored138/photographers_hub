<div class="top-profiles">
                            <div class="pf-hd">
                                <h3>Top Profiles</h3>
                                <i class="la la-ellipsis-v"></i>
                            </div>
                            <div class="profiles-slider">
                               
                            

<?php foreach($profile as $profiles): ?>
<div class="user-profy">
                                    <img src="./images/resources/user-pic.png" alt="user_profile" class="img">
                                    <h3>abhitej 2</h3>
                                    <span>Web Developer</span>
                                        <ul>
                                            <li><a href="./login?redirect_to=eyJpdiI6IjdBRlBzVWQ0WjBYd2pIekpOYVlTVXc9PSIsInZhbHVlIjoiaW5jNHhzZ2dsUm9CYWVraURIdzIyUT09IiwibWFjIjoiNjMyZDk0ZTk1MTIxZjUzODdlZTliZDA5ZmQzMmFlNzY1ZGE0MzNiMDkyYmU1NWE3NzkxNDkwMmRiZjVkYzcwYSJ9" title="Follow me" class="follow">Follow</a></li>
                                            <li><a href="./login?redirect_to=eyJpdiI6IjdnOENJVUV2ZDdFc0ZCM2R5SlpKTnc9PSIsInZhbHVlIjoiVVdYbDVndG1KVFd6c0ZNdHhFTGRYUT09IiwibWFjIjoiMTVmNWE3M2U0NmYxMmZkZTAxMjM3MmU3MTE4MTk5OWMyNDY0NGE5YjViNTRiNzcxMDU2YzE3MDhkNmU1MDFjOSJ9" title="" class="message-us"><i class="fa fa-envelope"></i></a></li>
                                        </ul>
                                        <a href="./user/abhitej" title="" class="view-more-pro">View Profile</a>
</div>

<?php endforeach; ?>

</div>
                        </div>