<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous">  <!-- Google Font: Source Sans Pro -->
<link rel="shortcut icon" href="<?= base_url() ?>assets/users/storage/admin/setting/files/fav.png1601638478.png">
<link rel="stylesheet" type="text/css" href="<?= base_url() ?>assets/users/css/animate.css">
<link rel="stylesheet" type="text/css" href="<?= base_url() ?>assets/users/css/bootstrap.min.css">
<link rel="stylesheet" type="text/css" href="<?= base_url() ?>assets/users/css/jquery.mCustomScrollbar.min.css">
<link rel="stylesheet" type="text/css" href="<?= base_url() ?>assets/users/css/slick.css">
<link rel="stylesheet" type="text/css" href="<?= base_url() ?>assets/users/css/slick-theme.css">
<link rel="stylesheet" type="text/css" href="<?= base_url() ?>assets/users/css/style.css">
<link rel="stylesheet" type="text/css" href="<?= base_url() ?>assets/users/css/responsive.css">
<link rel="stylesheet" type="text/css" href="<?= base_url() ?>assets/users/css/flatpickr.min.css">
<link rel="stylesheet" type="text/css" href="<?= base_url() ?>assets/users/css/custom.css">
<link rel="stylesheet" type="text/css" href="<?= base_url() ?>assets/users/css/buttons.css">
<link rel="stylesheet" type="text/css" href="<?= base_url() ?>assets/users/css/toast.css">
