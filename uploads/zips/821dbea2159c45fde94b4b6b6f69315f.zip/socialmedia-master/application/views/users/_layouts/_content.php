  <!-- Main content -->
    <?php echo @$_mainContent; ?>
