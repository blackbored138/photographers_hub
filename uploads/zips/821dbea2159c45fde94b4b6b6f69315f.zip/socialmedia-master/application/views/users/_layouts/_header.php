<header>
            <div class="container">
                <div class="header-data">
                    <div class="logo">
                        <a href="index.html" title=""><img src="https://gambolthemes.net/workwise-new/images/logo.png" alt=""></a>
                    </div>
                
                    <div class="search-bar">
                        <form>
                            <input type="text" name="search" placeholder="Search...">
                            <button type="submit"><i class="fa fa-search"></i></button>
                        </form>
                    </div>
                
                    <nav>
                        <ul>
                            <li>
                                <a href="<?= base_url() ?>userhome" title="Home">
                                <span><img src="https://gambolthemes.net/workwise-new/images/icon1.png" alt=""></span>
                                Home
                                </a>
                            </li>
                        
                            <li>
                                <a href="<?=base_url() ?>all_profiles" title="Profiles">
                                <span><img src="https://gambolthemes.net/workwise-new/images/icon2.png" alt=""></span>
                                Profiles
                                </a>
                            </li>
                        
                    
                        
                            <li>
                                <a href="#" title="" class="not-box-openm">
                                <span><img src="https://gambolthemes.net/workwise-new/images/icon6.png" alt=""></span>
                                Messages
                                </a>

                                <div class="notification-box msg message-modal-notification" id="message">
                                    <div class="nt-title">
                                        <h4>Setting</h4>
                                        <a href="#" title="">Clear all</a>
                                    </div>
                                    
                                    <div class="nott-list">
                                        <div class="notfication-details">
                                            <div class="noty-user-img">
                                                <img src="https://gambolthemes.net/workwise-new/images/resources/ny-img1.png" alt="">
                                            </div>         
                                            <div class="notification-info">
                                                <h3><a href="messages.html" title="">Jassica William</a> </h3>
                                                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do.</p>
                                                <span>2 min ago</span>
                                            </div>
                                        </div>

                                        <div class="notfication-details">
                                            <div class="noty-user-img">
                                                <img src="https://gambolthemes.net/workwise-new/images/resources/ny-img2.png" alt="">
                                            </div>
                                            <div class="notification-info">
                                                <h3><a href="messages.html" title="">Jassica William</a></h3>
                                                <p>Lorem ipsum dolor sit amet.</p>
                                                <span>2 min ago</span>
                                            </div>
                                        </div>
                                        
                                        <div class="view-all-nots">
                                        <a href="messages.html" title="">View All Messsages</a>
                                        </div>
                                    </div>
                                </div>
                            </li>
                        
                        </ul>
                    </nav>


                    <div class="menu-btn">
                        <a href="#" title=""><i class="fa fa-bars"></i></a>
                    </div>
                
                    <div class="user-account">
                        <div class="user-info">

                        <?php if($this->session->userdata('login_status')): ?> 

                            <img src="<?=base_url() ?>p_image/<?= $profile_image ?>/30/30" alt="User" />
                            <a href="javascript:void(0)" title="Username"><?=$this->session->userdata('user_name') ?></a> &nbsp;
                    
                        <?php else: ?>
                    
                            <img src="https://gambolthemes.net/workwise-new/images/resources/user.png" alt="Guest">
                            <a href="javascript:void(0)" title="Username">Guest</a> &nbsp;
                        <?php endif; ?>


                        </div>

                        <div class="user-account-settingss" id="user_profile_items_dropdown">
                            <a class="btn btn-danger btn-block user-info">Close</a>
                        
                            <?php if($this->session->userdata('login_status')): ?> 

                            <h3>Online</h3>

 
                                <ul class="us-links">
                                    <li><a href="<?=base_url() ?>settings" title="Settings">Account Setting</a></li>
                                    <li><a href="<?=base_url() ?>profile_image" title="Profile Picture">Profile Picture</a></li>
                                    <li><a href="#" title="">Privacy</a></li>
                                    <li><a href="#" title="">Faqs</a></li>
                                    <li><a href="#" title="">Terms & Conditions</a></li>
                                </ul>
                        
                                <a class="btn-block logout-button-header" href="<?= base_url() ?>authentication/logout" title="Logout">Logout</a>
                            <?php else: ?>   
                                <a class="btn-block login-button-header" target="_blank" href="<?= base_url() ?>authentication" title="Login">Login</a>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </header>