
<script type="text/javascript" src="<?= base_url() ?>assets/users/js/jquery.min.js"></script>
<script type="text/javascript" src="<?= base_url() ?>assets/users/js/popper.js"></script>
<script type="text/javascript" src="<?= base_url() ?>assets/users/js/bootstrap.min.js"></script>
<script type="text/javascript" src="<?= base_url() ?>assets/users/js/jquery.mCustomScrollbar.js"></script>
<script type="text/javascript" src="<?= base_url() ?>assets/users/js/slick.min.js"></script>
<script type="text/javascript" src="<?= base_url() ?>assets/users/js/scrollbar.js"></script>
<script type="text/javascript" src="<?= base_url() ?>assets/users/js/script.js"></script>
<script type="text/javascript" src="<?= base_url() ?>assets/users/js/toast.js"></script>
