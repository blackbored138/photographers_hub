<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title><?= $site_title ?></title>

<?php echo @$_meta ?>


<?php echo @$_css ?>

<?php echo @$_js ?>

</head>
<body>
<div class="wrapper" id="app">

<?php echo @$_header ?>

<?php echo @$_content  ?>

<?php echo @$_footer ?>
   
</div>


</body>
</html>
