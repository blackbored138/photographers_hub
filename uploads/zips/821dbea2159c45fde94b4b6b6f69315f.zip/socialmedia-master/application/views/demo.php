<head>
	<title>How to use Toastr</title>


</head>
<body>
	<div>
		<h1>How to use <b>Toastr</b></h1>
		<div>
			<h4>Popup Type</h4>
			<p>Toastr have 4 popup type and the different is icon and background</p>
			<button id="success" >Success</button>
			<button id="info" >Info</button>
			<button id="error" >Error</button>
			<button id="warning">Warning</button>
		</div>
		<br>
		<div>
			<h4>Image and Loading</h4>
			<p>Popup notification with image and progress bar</p>
			<button id="image">Image and Loading</button>
		</div>
		<br>
		<div>
			<h4>Position</h4>
			<p>There is 8 Toastr position support</p>
			<p>
			<form id="positionForm">
				<input type="radio" name="position" value="top-left" checked>Top Left
				<input type="radio" name="position" value="top-center">Top Center
				<input type="radio" name="position" value="top-right">Top Right
				<input type="radio" name="position" value="top-full-width">Top Full Width
				<input type="radio" name="position" value="bottom-left">Bottom Left
				<input type="radio" name="position" value="bottom-center">Bottom center
				<input type="radio" name="position" value="bottom-right">Bottom right
				<input type="radio" name="position" value="bottom-full-width">Bottom Full Width
			</form>
			</p>
			<button id="position">Show Toast</button>
		</div>
	</div>

	<script type="text/javascript">
	

	// Toast Position
		$('#position').click(function(event) {
			toastr.info('This sample position', 'Toast Position')
		});
	</script>
</body>
