<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Authentication extends CI_Controller {
	public function __construct() {
		parent::__construct();
		$this->load->model('M_auth');
		//auth_check();
	}

    public function index(){ 
		$data = array();
		$session = $this->session->userdata('login_status');

		if ($session == '') {
			$this->load->view('authentication/login',$data);
		} else {
			redirect('userhome');
		}    
    }

    public function upload_image(){ 
		auth_check();
		$data = array();
		$this->template->views('authentication/upload_image',$data);
		//$this->template->views('users/views/home',$result);
    }

    public function store_image(){ 
		auth_check();
		$user_id = magicfunction($this->session->userdata('user_id'),'d');

		$arr = $this->input->post();
		$data = $arr['photo'];

	
        
		
		list($type, $data) = explode(';', $data);
        list(, $data)      = explode(',', $data);
        $data = base64_decode($data);
        $image_name = time().'.png';
        $up_response = file_put_contents('uploads/profile_images/'.$image_name, $data);

		$qry_response = $this->M_auth->update_photo($image_name,$user_id);
		echo $up_response;
    }

    public function login(){
	check_post();
	$this->form_validation->set_rules('password', 'Password', 'required|trim');
	$this->form_validation->set_rules('username', 'Username', 'required|trim|min_length[4]|max_length[15]');

	if ($this->form_validation->run() == FALSE) {
		$msg['message'] = validation_errors();
		response(200,$msg);
		exit();
	}else{
		$username = trim($_POST['username']);
		$password = trim($_POST['password']);

		$data = $this->M_auth->login($username, $password);
		//print_r($data);
		//exit();

		if ($data == false) {
			$msg['message'] = 'Username or Password is wrong';
			response(200,$msg);
		} else {
			$token = rand(100000,9999999);
			$tokenEnc = md5($token);
			$session = [
				'user_id' => magicfunction($data->user_id,'e'),
				'user_type_display' =>$data->user_type,
				'user_name' =>$data->user_name,
				'enc_token' => $tokenEnc,
				'userdata' => $data,
				'login_status' => "Logged in"
			];
			$this->session->set_userdata($session);
			$msg['message'] = 'You are loggedin successfully';
			response(200,$msg);
		}
	} 
    }

    public function register(){
	check_post();
	$this->form_validation->set_rules('user_full_name', 'Full name', 'required|trim|min_length[4]|max_length[15]');
	$this->form_validation->set_rules('user_place', 'Place', 'required|trim');
	$this->form_validation->set_rules('user_phone', 'Phone', 'required|trim|numeric');
	$this->form_validation->set_rules('user_mail', 'Email', 'required|trim|valid_email');
	$this->form_validation->set_rules('user_gender', 'Gender', 'required|trim');
	$this->form_validation->set_rules('user_password', 'Password', 'required|trim');
	$this->form_validation->set_rules('repeat_password', 'Repeat Password', 'required|trim');
	$this->form_validation->set_rules('user_name', 'Username', 'required|trim|min_length[4]|max_length[15]');

	if ($this->form_validation->run() == FALSE) {
		$msg['message'] = validation_errors();
		response(200,$msg);
	}else{
		$token = rand(100000,9999999);
		$tokenEnc = md5($token);

		$user_arr = $this->input->post();

		$user_arr['user_password'] = magicfunction($user_arr['user_password'],'e');
		$user_arr['user_type'] = '2';
		$user_arr['user_token'] = $tokenEnc;
		$user_arr['user_verified'] = '0';
		$user_arr['user_photo'] = 'no image';
		
		unset($user_arr['_token']);
		unset($user_arr['repeat_password']);
		$data = $this->M_auth->register($user_arr);
		$user_id = $this->db->insert_id(); 
		$userdata = (object)$user_arr;

		//print_r($data);
		//exit();

		if ($data == false) {
			$msg['message'] = 'Unable to register,Try after some time';
			response(200,$msg);
		} else {

			$session = [
				'user_id' => magicfunction($user_id,'e'),
				'user_type_display' =>$userdata->user_type,
				'user_name' =>$userdata->user_name,
				'enc_token' => $tokenEnc,
				'userdata' => $userdata,
				'login_status' => "Logged in"
			];
			$this->session->set_userdata($session);
			$msg['message'] = 'You are registered,Verify email now';
			response(200,$msg);
		}
	} 
    }

    public function logout() {
		$this->session->sess_destroy();
		redirect('authentication');
	}

    public function demo() {
		
		$this->load->view('demo');

	}


    
}