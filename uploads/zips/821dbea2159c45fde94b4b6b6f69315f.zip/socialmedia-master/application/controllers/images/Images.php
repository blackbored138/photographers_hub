<?php defined('BASEPATH') OR exit('No direct script access allowed');
class Images extends CI_Controller
{

    public function index(){
        echo 2154;
    }
  
    public function profile_images($file, $new_width = 200, $new_height = 200) {
            $file = base_url().'uploads/profile_images/'.$file;

            $im = $this->resize_image($file,$new_width,$new_height);
            echo $im;
            exit();
    }
    
    public function user_posts($file, $new_width = 200, $new_height = 200) {
            $file = base_url().'uploads/user_posts/'.$file;

            $im = $this->resize_image($file,$new_width,$new_height);
            echo $im;
            exit();
    }


    public function create_avatar($character,$width,$height){
        $im = imagecreatetruecolor($width, $height);
        $background = imagecolorallocate($im , 255, 255, 255);
        imagefill($im, 0, 0, $background);	

        $color = imagecolorallocate($im , 7, 25, 68);
        $font = 'assets/fonts/rob.ttf';

       
        $tt = imagettftext($im, 100, 0, 50, 150, $color, $font, $character);
        
        header('Content-Type: image/png');

        imagepng($im);
        imagedestroy($im);
    }






    function resize_image($file, $new_width, $new_height){
        list($width, $height) = @getimagesize($file);    
            if(empty($width)){
                echo 'Show Placeholder image later!!';
                exit();
            }

        $info = getimagesize($file);

        if ($info['mime'] == 'image/jpeg') $im = imagecreatefromjpeg($file);
        elseif ($info['mime'] == 'image/gif') $im = imagecreatefromgif($file);
        elseif ($info['mime'] == 'image/png') $im = imagecreatefrompng($file);

        //$im = imagecreatefrompng($file);
        $img = imagecreatetruecolor($new_width,$new_height);

        $background = imagecolorallocate($img , 0, 0, 0);
        imagecolortransparent($img, $background);
        imagealphablending($img, false); 
        imagesavealpha($img, true);	
        
        imagecopyresampled($img, $im, 0, 0, 0, 0, $new_width, $new_height, $width, $height);

        
        header('Content-type: image/png');
        imagepng($img);
        imagedestroy($img);
    }

  
}
?>