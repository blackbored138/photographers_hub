<?php defined('BASEPATH') OR exit('No direct script access allowed');
	
class userhome extends MY_Controller {

	public function __construct(){
		parent::__construct();
    }

    public function index(){
        $this->load->model('M_profiles');
        $this->load->model('M_posts');
        
        $latest_profiles = $this->M_profiles->latest_profiles_front();
        $suggested_profiles = $this->M_profiles->suggested_profiles_front();
        $home_posts = $this->M_posts->posts_list();

        
        $enc_indexes1 = array('user_id');
        $enc_indexes2 = array('up_id','posted_by','post_unq_id');
        $home_posts = explode_data($home_posts,'post_files');

        $result['latest_profile'] = encrypt_data($latest_profiles,$enc_indexes1); 
        $result['suggested_profile'] = encrypt_data($suggested_profiles,$enc_indexes1); 
        $result['home_post'] = encrypt_data($home_posts,$enc_indexes2); 
  		  
        //print_r($result['home_post']); exit();
		    $this->template->views('users/views/home',$result);
	}

    
    public function all_profiles(){
		    $this->template->views('users/views/all_profiles');
	}

        
    public function profile_settings(){
		    $this->template->views('users/views/profile_settings');
	}      


  public function save_post(){
    $this->load->model('M_posts');
    $arr_name = '';
    $dts = $_POST['dts'];
		$ttt = explode(',',$dts);
		$others_image_last='';
		$image_link= "/uploads/user_posts/"; //folder name
		 
    $file_count = sizeof($_FILES['upload_files']['name']);
    for($i=0; $i< $file_count; $i++) {
      if (in_array($i+1, $ttt)){

      }else{	 
          $new_file = md5(microtime());
          $image_type = $_FILES["upload_files"]["type"][$i];
          $image_name = $_FILES["upload_files"]["name"][$i];
          $image_error = $_FILES["upload_files"]["error"][$i];
          $image_temp_name = $_FILES["upload_files"]["tmp_name"][$i];
            if (($image_type == "image/jpeg") || ($image_type == "image/png") || ($image_type == "image/pjpeg") || ($image_type == "image/jpg")) {
                $test = explode('.', $image_name);
                $name = $new_file.'.'.end($test);
                $url = '.'.$image_link. $name;
                $info = getimagesize($image_temp_name);
                if ($info['mime'] == 'image/jpeg') $image = imagecreatefromjpeg($image_temp_name);
                elseif ($info['mime'] == 'image/gif') $image = imagecreatefromgif($image_temp_name);
                elseif ($info['mime'] == 'image/png') $image = imagecreatefrompng($image_temp_name);

                imagejpeg($image,$url,50);
                imagedestroy($image);
            } 
          //echo $name;
          $arr_name .= $name;
          $arr_name .= ($i < $file_count - 1) ? ',' : '';

          

        }
		}
    //echo $arr_name; exit();
     /****** insert query here ******/
     $posts_arr['post_unq_id'] = time();
     $posts_arr['posted_by'] = magicfunction($this->session->userdata('user_id'),'d');
     $posts_arr['posted_on'] = date('Y-m-d h:m:s');
     $posts_arr['post_files'] = $arr_name;

     //print_r($posts_arr); exit();
     $posts_arr['post_text'] = $this->input->post('post_content_text');
     $data = $this->M_posts->save_posts($posts_arr);
  }

    public function demo(){
		$this->template->views('demo');
	}

    


}
