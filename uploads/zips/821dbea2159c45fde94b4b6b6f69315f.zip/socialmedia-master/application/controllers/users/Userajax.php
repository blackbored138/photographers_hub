<?php defined('BASEPATH') OR exit('No direct script access allowed');
	
class userajax extends MY_Controller {

	public function __construct(){
		parent::__construct();
    }

    public function profiles_list(){
        $this->load->model('M_profiles');
        $offset = $this->input->post('offset');
        $order = $this->input->post('order');
        $result = $this->M_profiles->profiles_list($offset,$order);

        $enc_indexes = array('user_id');
        $result['profile'] = encrypt_data($result,$enc_indexes); 
  		  

        //echo $this->db->last_query();
        $this->load->view('users/ajax/all_profiles_list',$result);
        //$this->response(200,$result);
	}

    public function latest_profiles_list(){
        $this->load->model('M_profiles');
        $result = $this->M_profiles->latest_profiles();

        $enc_indexes = array('user_id');
        $result['profile'] = encrypt_data($result,$enc_indexes); 
  		  

        $this->load->view('users/ajax/latest_profiles',$result);
        //$this->response(200,$result);
	}
    public function suggested_profiles_list(){
        $this->load->model('M_profiles');
        $result = $this->M_profiles->suggested_profiles_front();

        $enc_indexes = array('user_id');
        $result['profile'] = encrypt_data($result,$enc_indexes); 
  		  

        $this->load->view('users/ajax/latest_profiles',$result);
        //$this->response(200,$result);
	}

    
    public function profiles(){
		$this->template->views('users/profiles');
	}

    


}
