<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/*
| -------------------------------------------------------------------------
| URI ROUTING
| -------------------------------------------------------------------------
| This file lets you re-map URI requests to specific controller functions.
|
| Typically there is a one-to-one relationship between a URL string
| and its corresponding controller class/method. The segments in a
| URL normally follow this pattern:
|
|	example.com/class/method/id/
|
| In some instances, however, you may want to remap this relationship
| so that a different class/function is called than the one
| corresponding to the URL.
|
| Please see the user guide for complete details:
|
|	https://codeigniter.com/user_guide/general/routing.html
|
| -------------------------------------------------------------------------
| RESERVED ROUTES
| -------------------------------------------------------------------------
|
| There are three reserved routes:
|
|	$route['default_controller'] = 'welcome';
|
| This route indicates which controller class should be loaded if the
| URI contains no data. In the above example, the "welcome" class
| would be loaded.
|
|	$route['404_override'] = 'errors/page_missing';
|
| This route will tell the Router which controller/method to use if those
| provided in the URL cannot be matched to a valid route.
|
|	$route['translate_uri_dashes'] = FALSE;
|
| This is not exactly a route, but allows you to automatically route
| controller and method names that contain dashes. '-' isn't a valid
| class or method name character, so it requires translation.
| When you set this option to TRUE, it will replace ALL dashes in the
| controller and method URI segments.
|
| Examples:	my-controller/index	-> my_controller/index
|		my-controller/my-method	-> my_controller/my_method
*/
$route['default_controller'] = 'authentication';
$route['404_override'] = '';
$route['translate_uri_dashes'] = FALSE;
$route['p_image/(:any)/(:any)/(:any)'] = 'images/images/profile_images/$1/$2/$3';
$route['u_posts/(:any)/(:any)/(:any)'] = 'images/images/user_posts/$1/$2/$3';
$route['c_avatar/(:any)/(:any)/(:any)'] = 'images/images/create_avatar/$1/$2/$3';



/**********Authentication************/

$route['login'] = 'authentication';
$route['profile_image'] = 'authentication/upload_image';
$route['profile_image_store']['post'] = 'authentication/store_image';
$route['login_api']['post'] = 'authentication/login';
$route['register_api']['post'] = 'authentication/register';

/**********Authentication************/


/**********Users************/

$route['userhome'] = 'users/userhome';
$route['all_profiles'] = 'users/userhome/all_profiles';
$route['profile'] = 'users/userhome/profile';
$route['settings'] = 'users/userhome/profile_settings';

$route['profileslist'] = 'users/userajax/profiles_list';
$route['latestprofiles'] = 'users/userajax/latest_profiles_list';


$route['save_post']['post'] = 'users/userhome/save_post';

/**********Users************/
