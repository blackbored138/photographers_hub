<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class M_auth extends CI_Model {
	
    public function login($user, $pass) {
		$this->db->select('user_id, user_full_name, user_place, user_phone, 
		user_mail, user_gender, user_name, user_password, user_type, 
		user_photo, user_token, user_verified, user_verified_on, 
		user_submitted_on, user_verified_by');
		$this->db->from('ci_users');
		$this->db->where('ci_users.user_name', $user);
		$this->db->where('ci_users.user_password', magicfunction($pass,'e'));
		$data = $this->db->get();

		if ($data->num_rows() == 1) {
			return $data->row();
		} else {
			return false;
		}
	}

	public function register($data){
        $result = $this->db->insert('ci_users',$data);
		return $result;		
    }
  
	public function update_photo($image,$id){
		$this->db->set('user_photo',$image);
		$this->db->where('user_id', $id);
		$this->db->update('ci_users');
		return true;	
    }
  
}

?>