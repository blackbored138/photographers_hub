<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class M_profiles extends CI_Model {
	
    public function profiles_list($offset = 0,$order = 'RANDOM') {
		$limit = '5';
		$this->db->select('user_id, user_full_name, user_place, user_phone, 
		user_mail, user_gender, user_name ,
		user_photo, user_verified_on, 
		user_submitted_on');
		$this->db->where('ci_users.status', 1);
		$this->db->where('ci_users.user_verified', 1);
		$this->db->order_by("user_id", $order); 
		$this->db->limit($limit, $offset);
		return $this->db->get('ci_users')->result();
	}
	
    public function latest_profiles_front() {

		$this->db->select('user_id, user_full_name, user_place, user_phone, 
		user_mail, user_gender, user_name ,
		user_photo, user_verified_on, 
		user_submitted_on');
		$this->db->where('ci_users.status', 1);
		$this->db->where('ci_users.user_verified', 1);
		$this->db->order_by("user_id", "desc"); 
		return $this->db->get('ci_users',10)->result();
	}

    public function suggested_profiles_front() {

		$this->db->select('user_id, user_full_name, user_place, user_phone, 
		user_mail, user_gender, user_name ,
		user_photo, user_verified_on, 
		user_submitted_on');
		$this->db->where('ci_users.status', 1);
		$this->db->where('ci_users.user_verified', 1);
		$this->db->order_by('user_id', 'RANDOM');
		return $this->db->get('ci_users',10)->result();
	}

	public function register($data){
        $result = $this->db->insert('ci_users',$data);
		return $result;		
    }
  
}

?>