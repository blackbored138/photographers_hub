<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class M_posts extends CI_Model {
	
    public function posts_list($offset = 0,$order = 'RANDOM') {
		$limit = '5';
		$this->db->select('ci_users_posts.up_id, ci_users_posts.post_text, 
		ci_users_posts.post_files, ci_users_posts.posted_by, ci_users_posts.posted_on, 
		ci_users_posts.post_unq_id,ci_users.user_full_name,ci_users.user_photo,ci_users.user_name');
		$this->db->join('ci_users', 'ci_users.user_id = ci_users_posts.posted_by');

		$this->db->where('ci_users_posts.status', 1);
		$this->db->where('ci_users.user_verified', 1);
		$this->db->order_by("up_id", $order); 
		$this->db->limit($limit, $offset);
		return $this->db->get('ci_users_posts')->result();
	}
	
    public function latest_profiles_front() {

		$this->db->select('user_id, user_full_name, user_place, user_phone, 
		user_mail, user_gender, user_name ,
		user_photo, user_verified_on, 
		user_submitted_on');
		$this->db->where('ci_users.status', 1);
		$this->db->where('ci_users.user_verified', 1);
		$this->db->order_by("user_id", "desc"); 
		return $this->db->get('ci_users',10)->result();
	}

    public function suggested_profiles_front() {

		$this->db->select('user_id, user_full_name, user_place, user_phone, 
		user_mail, user_gender, user_name ,
		user_photo, user_verified_on, 
		user_submitted_on');
		$this->db->where('ci_users.status', 1);
		$this->db->where('ci_users.user_verified', 1);
		$this->db->order_by('user_id', 'RANDOM');
		return $this->db->get('ci_users',10)->result();
	}

	public function save_posts($data){
        $result = $this->db->insert('ci_users_posts',$data);
		return $result;		
    }
  
}

?>