<?php
	class Template {
		protected $_ci;

		function __construct() {
			$this->_ci = &get_instance(); 

            $CI = & get_instance(); 
			$uid = magicfunction($CI->session->userdata('user_id'),'d');
			$result = $CI->db->get_where('ci_users', array('user_id' => $uid));

            if($result->num_rows() > 0){
                $result = $result->row_array();
				$this->profile_image = $result['user_photo'];
				//print_r($profile_image); exit();
            }
		}

		function views($template = NULL, $data = NULL) {

			if ($template != NULL) {
                $data['site_title'] = 'Social Media Project';
                $data['profile_image'] = $this->profile_image;

				
				// head
				$data['_meta'] 					= $this->_ci->load->view('users/_layouts/_meta', $data, TRUE);
				$data['_css'] 					= $this->_ci->load->view('users/_layouts/_css', $data, TRUE);
				
				// Header
				$data['_header'] 				= $this->_ci->load->view('users/_layouts/_header', $data, TRUE);
				

				//Content
				$data['_mainContent'] 		= $this->_ci->load->view($template, $data, TRUE);
				$data['_content'] 				= $this->_ci->load->view('users/_layouts/_content', $data, TRUE);
				
				//Footer
				$data['_footer'] 				= $this->_ci->load->view('users/_layouts/_footer', $data, TRUE);
				
				//JS
				$data['_js'] 					= $this->_ci->load->view('users/_layouts/_js', $data, TRUE);

				echo $data['_template'] 		= $this->_ci->load->view('users/_layouts/_template', $data, TRUE);
			}
		}
	}
?>