<?php

	class MY_Controller extends CI_Controller

	{
        function __construct()

		{
        parent::__construct();
		$this->load->helper('url');
		$this->load->library('session');
        $this->load->library('image_lib');
        //auth_check();
        }

        function response($status,$data)
        {
            header("HTTP/1.1 ".$status);
            
            $response['status']=$status;
            $response['data']=$data;
            
            $json_response = json_encode($response);
            echo $json_response;
            exit();
        }

       
    }
    ?>